# tateti
Repositorio de tp final de introducción a la programación
*******************
CARRERA: TECNICATURA UNIVERSITARIA EN DESARROLLO WEB
*******************
MATERIA: INTRODUCCION A LA PROGRAMACION
*******************
TRABAJO FINAL: TATETI
*********** GRUPO 7 ************
/**************************************/
/***** DATOS DE LOS INTEGRANTES *******/
/**************************************/
/* Apellido, Nombre. Legajo. Carrera. mail. Usuario Github */
Hitter, Maximiliano Ariel. FAI-3523. TUDW. maximiliano.hitter@est.fi.uncoma.edu.ar. MaximilianoHitter. 
Klimisch, Marcia Leonela. FAI-3573. TUDW. marcia.klimisch@est.fi.uncoma.edu.ar. Khaleesi89.
Duarte, Micaela Florencia. FAI-3252. TUDW. micaela.duarte@est.fi.uncoma.edu.ar. micaeladuarte
*****************
PROFESORES:
            ROTTER María José
            LUCERO Sandra
            ROZAS Karina
            TORCHINSKY David
*****************
